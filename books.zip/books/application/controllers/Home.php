<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{ 
		$query = $this->db->query('select book_id,book_title,book_author,book_language,book_available_status from tb_books');
		$result['data'] = $query->result();

		$this->load->view('home',$result);
	}

	public function login()
	{

		$this->load->library('form_validation');

		$this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('passwords', 'Password', 'required',
        	array('required' => 'You must provide a %s.'));

    	if ($this->form_validation->run() == FALSE)
        {
        	$this->load->view('login');
        }
        else{
        	if($_POST['username']=='admin' && $_POST['passwords']=='admin'){
        		$this->session->set_userdata('username','admin');
        		$url = base_url('admin');
        		header("Location:".$url);
        	}

        }

	}


}
